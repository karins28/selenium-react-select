# react-select-selenium
a library for react select selenium actions
